import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from operations_api import operations

while True:
    response = operations.request_operation(1)
    read_input = input("Enter a number: ")
    print("You entered: ", read_input)
