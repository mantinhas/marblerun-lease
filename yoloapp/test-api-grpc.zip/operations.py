import grpc
from rpc import marble_pb2
from rpc import marble_pb2_grpc

def request_operation(amount=1):
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = marble_pb2_grpc.OperationTrackerStub(channel)
        response = stub.StartOperation(marble_pb2.StartOperationReq(nOperations=int(amount)))
    return response.ok
