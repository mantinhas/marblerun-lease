from operations import operation_start

while True:
    response = request_operation(1)
    read_input = input("Enter a number: ")
    print("You entered: ", read_input)
